import React, { Fragment } from "react";
import Sidebar from "../Components/Layout/Sidebar/Sidebar";

function App() {
    return (
        <Fragment>
            <Sidebar />
        </Fragment>
    );
}

export default App;
