import React, { Fragment } from "react";
import classes from "./Sidebar.module.css";
const Sidebar = () => {
    return <div className={classes.sidebar}></div>;
};
export default Sidebar;
