

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <form action="<?php echo e(url('api/csv/upload')); ?>" method="post">
            <div class="custom-file">
                <input type="file" class="custom-file-input" name="file" id="customFile">
                <label class="custom-file-label" for="customFile">Choose file</label>
            </div>
            <button class="btn btn-primary" type="submit">Submit form</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nkItService\react-backend\resources\views/csv.blade.php ENDPATH**/ ?>